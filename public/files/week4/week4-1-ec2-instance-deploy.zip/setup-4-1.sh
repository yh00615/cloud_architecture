#!/bin/bash

# UTF-8 인코딩 설정 (로케일 오류 방지)
export LANG=${LANG:-en_US.UTF-8}
export LC_ALL=${LC_ALL:-en_US.UTF-8}
export LC_CTYPE=${LC_CTYPE:-en_US.UTF-8}
# ===========================================
# Week4-1: Amazon EC2 인스턴스 배포 - 최적 서버 구성 및 관리
# 목적: EC2 실습을 위한 기본 VPC 네트워크 환경 생성 (NAT Gateway 제외)
# 예상 시간: 약 5분
# 예상 비용: 기본 VPC 리소스는 무료
# 
# 구성 요소:
# - VPC: CloudArchitect-Lab-VPC (10.0.0.0/16)
# - Public Subnet: CloudArchitect-Lab-Public-Subnet (10.0.0.0/24, ap-northeast-2a)
# - Internet Gateway: CloudArchitect-Lab-IGW
# - Security Group: CloudArchitect-Lab-Web-SG (HTTP, HTTPS, SSH)
# 
# 학생 실습 내용:
# - EC2 인스턴스는 실습 가이드에서 직접 생성
# - User Data를 통한 Apache 설치 실습
# - Security Group 규칙 설정 실습
# ===========================================





# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 공통 함수들
show_progress() {
    local current=$1
    local total=$2
    local message=$3
    echo -e "${PURPLE}🔥 [$current/$total] $message${NC}"
}

show_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

show_info() {
    echo -e "${CYAN}ℹ️ $1${NC}"
}

show_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

show_error() {
    echo -e "${RED}❌ $1${NC}"
}

show_step() {
    echo -e "${CYAN}📋 $1${NC}"
}

show_important() {
    echo -e "${PURPLE}🔥 $1${NC}"
}

# 단계별 대기 함수
wait_for_next_step() {
    echo ""
    echo -e "${CYAN}⏳ 다음 단계 준비 중...${NC}"
    sleep 2
    echo ""
}

# AWS CLI 프로필 및 리전 확인
get_aws_account_info() {
    local account_id=$(aws sts get-caller-identity --query Account --output text 2>/dev/null)
    local region=$(aws configure get region 2>/dev/null || echo "")
    local user_arn=$(aws sts get-caller-identity --query Arn --output text 2>/dev/null)
    
    if [ -z "$account_id" ] || [ "$account_id" = "None" ]; then
        show_error "AWS 자격 증명을 확인할 수 없습니다."
        show_info "다음 명령어로 AWS CLI를 설정해주세요:"
        echo "  aws configure"
        exit 1
    fi
    
    if [ -z "$region" ] || [ "$region" = "None" ]; then
        show_error "AWS 리전이 설정되지 않았습니다."
        show_info "다음 명령어로 리전을 설정해주세요:"
        echo "  aws configure set region ap-northeast-2"
        exit 1
    fi
    
    echo "$account_id:$region:$user_arn"
}

# 생성 계획 표시 함수
show_creation_plan() {
    echo ""
    show_important "🚀 생성 계획:"
    echo ""
    echo "  📋 네트워크 인프라 구성:"
    echo "    🌐 VPC: CloudArchitect-Lab-VPC (10.0.0.0/16)"
    echo "    🌍 Internet Gateway: CloudArchitect-Lab-IGW"
    echo ""
    echo "  🏢 서브넷 구성:"
    echo "    🔓 Public Subnet: CloudArchitect-Lab-Public-Subnet (10.0.0.0/24, ap-northeast-2a)"
    echo ""
    echo "  🛡️ 보안 구성:"
    echo "    🌐 Web Security Group: CloudArchitect-Lab-Web-SG"
    echo "      • HTTP (80), HTTPS (443), SSH (22) 허용"
    echo ""
    echo "  🎯 핵심 학습 목표:"
    echo "    • EC2 인스턴스 생성 및 관리"
    echo "    • User Data를 통한 자동 소프트웨어 설치"
    echo "    • Security Group을 통한 네트워크 보안"
    echo ""
    echo "  ⚠️ 주의사항:"
    echo "    • EC2 인스턴스 생성 시 과금될 수 있음"
    echo "    • 실습 완료 후 cleanup 스크립트 실행 필수"
    echo "    • 예상 소요 시간: 약 5분"
    echo ""
}

# 사용자 확인 함수
confirm_creation() {
    echo ""
    read -p "위 계획대로 Week4-1 리소스를 생성하시겠습니까? (y/N): " confirm
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        show_info "Week4-1 설정이 취소되었습니다."
        exit 0
    fi
    show_info "Week4-1 리소스 생성을 시작합니다..."
    echo ""
}



# ===========================================
# VPC 생성/재사용 함수
# ===========================================
create_vpc() {
    show_info "VPC 확인/생성 중..."
    
    # 기존 VPC 확인
    VPC_ID=$(aws ec2 describe-vpcs \
        --filters \
            "Name=tag:Name,Values=CloudArchitect-Lab-VPC" \
            "Name=cidr-block-association.cidr-block,Values=10.0.0.0/16" \
            "Name=state,Values=available" \
        --query 'Vpcs[0].VpcId' \
        --output text 2>/dev/null)
    
    if [ "$VPC_ID" != "None" ] && [ -n "$VPC_ID" ]; then
        show_success "🔄 기존 VPC 재사용: CloudArchitect-Lab-VPC ($VPC_ID)"
        return 0
    fi
    
    show_info "새 VPC 생성 중..."
    VPC_ID=$(aws ec2 create-vpc \
        --cidr-block 10.0.0.0/16 \
        --tag-specifications 'ResourceType=vpc,Tags=[{Key=Name,Value=CloudArchitect-Lab-VPC},{Key=Project,Value=CloudArchitect},{Key=Lab,Value=Week4-1},{Key=Component,Value=Network},{Key=CreatedBy,Value=setup-week4-1-student.sh}]' \
        --query 'Vpc.VpcId' --output text 2>&1)
    
    if [ -z "$VPC_ID" ] || [ "$VPC_ID" = "None" ]; then
        show_error "VPC 생성 실패"
        show_info "가능한 원인:"
        echo "  • VPC 생성 권한 부족"
        echo "  • VPC 할당량 초과"
        echo "  • 네트워크 연결 문제"
        exit 1
    fi
    
    # DNS 설정 활성화
    if ! aws ec2 modify-vpc-attribute --vpc-id $VPC_ID --enable-dns-hostnames 2>/dev/null; then
        show_error "VPC DNS hostnames 활성화 실패"
        exit 1
    fi
    
    if ! aws ec2 modify-vpc-attribute --vpc-id $VPC_ID --enable-dns-support 2>/dev/null; then
        show_error "VPC DNS support 활성화 실패"
        exit 1
    fi
    
    # DNS 설정 검증
    local dns_hostnames=$(aws ec2 describe-vpc-attribute --vpc-id $VPC_ID --attribute enableDnsHostnames --query 'EnableDnsHostnames.Value' --output text 2>/dev/null)
    local dns_support=$(aws ec2 describe-vpc-attribute --vpc-id $VPC_ID --attribute enableDnsSupport --query 'EnableDnsSupport.Value' --output text 2>/dev/null)
    
    if [ "$dns_hostnames" != "True" ] || [ "$dns_support" != "True" ]; then
        show_error "VPC DNS 설정 검증 실패"
        exit 1
    fi
    
    show_success "✨ VPC 생성 완료: CloudArchitect-Lab-VPC ($VPC_ID)"
}

# ===========================================
# Internet Gateway 생성/재사용 함수
# ===========================================
create_internet_gateway() {
    show_info "Internet Gateway 확인/생성 중..."
    
    # 기존 IGW 확인
    IGW_ID=$(aws ec2 describe-internet-gateways \
        --filters \
            "Name=tag:Name,Values=CloudArchitect-Lab-IGW" \
            "Name=attachment.vpc-id,Values=$VPC_ID" \
            "Name=attachment.state,Values=available" \
        --query 'InternetGateways[0].InternetGatewayId' \
        --output text 2>/dev/null)
    
    if [ "$IGW_ID" != "None" ] && [ -n "$IGW_ID" ]; then
        show_success "🔄 기존 Internet Gateway 재사용: CloudArchitect-Lab-IGW ($IGW_ID)"
        return 0
    fi
    
    show_info "새 Internet Gateway 생성 중..."
    IGW_ID=$(aws ec2 create-internet-gateway \
        --tag-specifications 'ResourceType=internet-gateway,Tags=[{Key=Name,Value=CloudArchitect-Lab-IGW},{Key=Project,Value=CloudArchitect},{Key=Lab,Value=Week4-1},{Key=Component,Value=Network},{Key=CreatedBy,Value=setup-week4-1-student.sh}]' \
        --query 'InternetGateway.InternetGatewayId' --output text 2>&1)
    
    if [ -z "$IGW_ID" ] || [ "$IGW_ID" = "None" ]; then
        show_error "Internet Gateway 생성 실패"
        show_info "가능한 원인:"
        echo "  • IGW 생성 권한 부족"
        echo "  • 네트워크 연결 문제"
        exit 1
    fi
    
    # VPC에 연결
    if ! aws ec2 attach-internet-gateway --vpc-id $VPC_ID --internet-gateway-id $IGW_ID 2>/dev/null; then
        show_error "Internet Gateway VPC 연결 실패"
        exit 1
    fi
    
    # IGW 연결 상태 검증
    local attachment_state=$(aws ec2 describe-internet-gateways \
        --internet-gateway-ids $IGW_ID \
        --query 'InternetGateways[0].Attachments[0].State' \
        --output text 2>/dev/null)
    
    if [ "$attachment_state" != "available" ]; then
        show_error "Internet Gateway 연결 상태 검증 실패 (상태: $attachment_state)"
        exit 1
    fi
    
    show_success "✨ Internet Gateway 생성 및 연결 완료: CloudArchitect-Lab-IGW ($IGW_ID)"
}

# ===========================================
# Public Subnet 생성/재사용 함수
# ===========================================
create_public_subnet() {
    show_info "Public Subnet 확인/생성 중..."
    
    # 기존 Public Subnet 확인
    PUBLIC_SUBNET_ID=$(aws ec2 describe-subnets \
        --filters \
            "Name=tag:Name,Values=CloudArchitect-Lab-Public-Subnet" \
            "Name=vpc-id,Values=$VPC_ID" \
            "Name=cidr-block,Values=10.0.0.0/24" \
            "Name=availability-zone,Values=${REGION}a" \
            "Name=state,Values=available" \
        --query 'Subnets[0].SubnetId' \
        --output text 2>/dev/null)
    
    if [ "$PUBLIC_SUBNET_ID" != "None" ] && [ -n "$PUBLIC_SUBNET_ID" ]; then
        show_success "🔄 기존 Public Subnet 재사용: CloudArchitect-Lab-Public-Subnet ($PUBLIC_SUBNET_ID)"
    else
        show_info "새 Public Subnet 생성 중..."
        PUBLIC_SUBNET_ID=$(aws ec2 create-subnet \
            --vpc-id $VPC_ID \
            --cidr-block 10.0.0.0/24 \
            --availability-zone ${REGION}a \
            --tag-specifications 'ResourceType=subnet,Tags=[{Key=Name,Value=CloudArchitect-Lab-Public-Subnet},{Key=Project,Value=CloudArchitect},{Key=Lab,Value=Week4-1},{Key=Component,Value=Network},{Key=Type,Value=Public},{Key=AZ,Value=2a},{Key=CreatedBy,Value=setup-week4-1-student.sh}]' \
            --query 'Subnet.SubnetId' --output text 2>&1)
        
        if [ -z "$PUBLIC_SUBNET_ID" ] || [ "$PUBLIC_SUBNET_ID" = "None" ]; then
            show_error "Public Subnet 생성 실패"
            show_info "가능한 원인:"
            echo "  • Subnet 생성 권한 부족"
            echo "  • CIDR 블록 충돌"
            echo "  • 가용 영역 문제"
            exit 1
        fi
        show_success "✨ Public Subnet 생성 완료: CloudArchitect-Lab-Public-Subnet ($PUBLIC_SUBNET_ID)"
    fi
    
    # Public IP 자동 할당 설정
    if ! aws ec2 modify-subnet-attribute --subnet-id $PUBLIC_SUBNET_ID --map-public-ip-on-launch 2>/dev/null; then
        show_error "Public IP 자동 할당 설정 실패"
        exit 1
    fi
    
    # Public IP 자동 할당 설정 검증
    local map_public_ip=$(aws ec2 describe-subnets --subnet-ids $PUBLIC_SUBNET_ID --query 'Subnets[0].MapPublicIpOnLaunch' --output text 2>/dev/null)
    if [ "$map_public_ip" != "True" ]; then
        show_error "Public IP 자동 할당 설정 검증 실패"
        exit 1
    fi
    
    # Route Table 생성 및 설정
    show_info "Route Table 설정 중..."
    
    # 기존 Route Table 확인
    PUBLIC_RT_ID=$(aws ec2 describe-route-tables \
        --filters \
            "Name=tag:Name,Values=CloudArchitect-Lab-Public-RT" \
            "Name=vpc-id,Values=$VPC_ID" \
        --query 'RouteTables[0].RouteTableId' \
        --output text 2>/dev/null)
    
    if [ "$PUBLIC_RT_ID" = "None" ] || [ -z "$PUBLIC_RT_ID" ]; then
        show_info "새 Route Table 생성 중..."
        PUBLIC_RT_ID=$(aws ec2 create-route-table \
            --vpc-id $VPC_ID \
            --tag-specifications 'ResourceType=route-table,Tags=[{Key=Name,Value=CloudArchitect-Lab-Public-RT},{Key=Project,Value=CloudArchitect},{Key=Lab,Value=Week4-1},{Key=Component,Value=Network},{Key=Type,Value=Public},{Key=CreatedBy,Value=setup-week4-1-student.sh}]' \
            --query 'RouteTable.RouteTableId' --output text 2>&1)
        
        if [ -z "$PUBLIC_RT_ID" ] || [ "$PUBLIC_RT_ID" = "None" ]; then
            show_error "Route Table 생성 실패"
            exit 1
        fi
        show_success "✨ Route Table 생성 완료: CloudArchitect-Lab-Public-RT ($PUBLIC_RT_ID)"
    else
        show_success "🔄 기존 Route Table 재사용: CloudArchitect-Lab-Public-RT ($PUBLIC_RT_ID)"
    fi
    
    # 인터넷 게이트웨이로의 라우트 추가
    if ! aws ec2 create-route --route-table-id $PUBLIC_RT_ID --destination-cidr-block 0.0.0.0/0 --gateway-id $IGW_ID 2>/dev/null; then
        show_warning "Route 생성 실패 또는 이미 존재함"
    fi
    
    # 서브넷을 라우트 테이블에 연결
    if ! aws ec2 associate-route-table --subnet-id $PUBLIC_SUBNET_ID --route-table-id $PUBLIC_RT_ID 2>/dev/null; then
        show_warning "Route Table 연결 실패 또는 이미 연결됨"
    fi
    
    show_success "Route Table 설정 완료"
}

# ===========================================
# Security Group 생성/재사용 함수
# ===========================================
create_security_group() {
    show_info "Security Group 확인/생성 중..."
    
    # 기존 Web Security Group 확인
    WEB_SG_ID=$(aws ec2 describe-security-groups \
        --filters "Name=group-name,Values=CloudArchitect-Lab-Web-SG" "Name=vpc-id,Values=$VPC_ID" \
        --query 'SecurityGroups[0].GroupId' \
        --output text 2>/dev/null)
    
    if [ "$WEB_SG_ID" != "None" ] && [ -n "$WEB_SG_ID" ]; then
        show_success "🔄 기존 Web Security Group 재사용: CloudArchitect-Lab-Web-SG ($WEB_SG_ID)"
    else
        show_info "새 Web Security Group 생성 중..."
        WEB_SG_ID=$(aws ec2 create-security-group \
            --group-name CloudArchitect-Lab-Web-SG \
            --description "CloudArchitect Week4-1 - Web Server Security Group" \
            --vpc-id $VPC_ID \
            --tag-specifications 'ResourceType=security-group,Tags=[{Key=Name,Value=CloudArchitect-Lab-Web-SG},{Key=Project,Value=CloudArchitect},{Key=Lab,Value=Week4-1},{Key=Component,Value=Security},{Key=Type,Value=Web},{Key=CreatedBy,Value=setup-week4-1-student.sh}]' \
            --query 'GroupId' --output text 2>&1)
        
        if [ -z "$WEB_SG_ID" ] || [ "$WEB_SG_ID" = "None" ]; then
            show_error "Security Group 생성 실패"
            exit 1
        fi
        
        # 인바운드 규칙 추가
        if ! aws ec2 authorize-security-group-ingress --group-id $WEB_SG_ID --protocol tcp --port 80 --cidr 0.0.0.0/0 2>/dev/null; then
            show_error "HTTP 규칙 추가 실패"
            exit 1
        fi
        
        if ! aws ec2 authorize-security-group-ingress --group-id $WEB_SG_ID --protocol tcp --port 443 --cidr 0.0.0.0/0 2>/dev/null; then
            show_error "HTTPS 규칙 추가 실패"
            exit 1
        fi
        
        if ! aws ec2 authorize-security-group-ingress --group-id $WEB_SG_ID --protocol tcp --port 22 --cidr 0.0.0.0/0 2>/dev/null; then
            show_error "SSH 규칙 추가 실패"
            exit 1
        fi
                
        show_success "✨ Web Security Group 생성 완료: CloudArchitect-Lab-Web-SG ($WEB_SG_ID)"
    fi
}



# 완료 요약 표시 함수
show_completion_summary() {
    echo ""
    show_success "🎉 Week4-1 EC2 기초 인프라 구축이 완료되었습니다!"
    echo ""
    
    echo "📋 생성된 주요 리소스:"
    echo "  ✅ VPC: CloudArchitect-Lab-VPC ($VPC_ID)"
    echo "  ✅ Internet Gateway: CloudArchitect-Lab-IGW ($IGW_ID)"
    echo "  ✅ Public Subnet: CloudArchitect-Lab-Public-Subnet ($PUBLIC_SUBNET_ID)"
    echo "  ✅ Route Table: CloudArchitect-Lab-Public-RT ($PUBLIC_RT_ID)"
    echo "  ✅ Security Group: CloudArchitect-Lab-Web-SG ($WEB_SG_ID)"
    echo ""
    
    echo "🚀 다음 단계:"
    echo "  • 이제 Week4-1 EC2 인스턴스 생성 실습을 진행할 수 있습니다"
    echo "  • 실습 가이드에 따라 EC2 인스턴스를 직접 생성하세요"
    echo "  • User Data를 통한 Apache 설치 실습 가능"
    echo ""
    
    echo "💰 비용 절약: cleanup 스크립트로 리소스를 정리하세요"
    echo ""
    
    show_success "Week4-1 스크립트 실행 완료"
}

# 메인 실행 함수
main() {
    # AWS 계정 정보 확인
    local aws_info=$(get_aws_account_info)
    local account_id=$(echo "$aws_info" | cut -d':' -f1)
    local region=$(echo "$aws_info" | cut -d':' -f2)
    local user_arn=$(echo "$aws_info" | cut -d':' -f3)
    
    # REGION 변수를 전역으로 export
    export REGION="$region"
    
    # 헤더 표시
    echo "================================"
    echo "Week4-1: Amazon EC2 인스턴스 배포 - 최적 서버 구성 및 관리"
    echo "================================"
    echo "목적: EC2 실습을 위한 기본 VPC 네트워크 환경 생성"
    echo "예상 시간: 약 5분"
    echo "예상 비용: 기본 VPC 리소스는 무료"
    echo "================================"
    echo ""
    
    # AWS 환경 확인
    show_info "AWS 환경 확인 중..."
    echo "현재 리전: $region"
    echo "계정 ID: $account_id"
    echo ""
    
    # 필수 권한 확인
    show_info "필수 AWS 서비스 권한 확인 중..."
    aws ec2 describe-vpcs --max-items 1 >/dev/null 2>&1 && show_success "VPC 권한 확인 완료" || show_warning "VPC 권한 제한됨"
    echo ""
    
    # 생성 계획 표시 및 사용자 확인
    show_creation_plan
    confirm_creation
    
    # 리소스 생성 (단계별)
    show_progress 1 4 "VPC 생성 중..."
    create_vpc
    echo ""
    
    show_progress 2 4 "Internet Gateway 생성 중..."
    create_internet_gateway
    echo ""
    
    show_progress 3 4 "Public Subnet 생성 중..."
    create_public_subnet
    echo ""
    
    show_progress 4 4 "Security Group 생성 중..."
    create_security_group
    echo ""
    
    # 완료 요약
    show_completion_summary
}

# 스크립트 실행
main "$@"