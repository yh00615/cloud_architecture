#!/bin/bash

# UTF-8 인코딩 설정 (로케일 오류 방지)
export LANG=${LANG:-en_US.UTF-8}
export LC_ALL=${LC_ALL:-en_US.UTF-8}
export LC_CTYPE=${LC_CTYPE:-en_US.UTF-8}
# ===========================================
# Week10: Amazon ECS 서비스 배포 - 컨테이너 오케스트레이션 관리 정리
# 목적: Week10에서 생성된 ECR 리포지토리를 안전하게 정리
# ===========================================



# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 공통 함수들
show_progress() {
    local current=$1
    local total=$2
    local message=$3
    echo -e "${PURPLE}🔥 [$current/$total] $message${NC}"
}

show_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

show_info() {
    echo -e "${CYAN}ℹ️ $1${NC}"
}

show_warning() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

show_error() {
    echo -e "${RED}❌ $1${NC}"
}

show_important() {
    echo -e "${PURPLE}🔥 $1${NC}"
}

show_step() {
    echo -e "${CYAN}📋 $1${NC}"
}

# VPC 인프라 정리 함수 (Demo04 기반)
cleanup_vpc_infrastructure() {
    show_info "VPC 네트워크 인프라 정리 중..."
    
    local vpc_name="CloudArchitect-Lab-VPC"
    
    # VPC 확인
    local vpc_id=$(aws ec2 describe-vpcs \
        --filters "Name=tag:Name,Values=$vpc_name" "Name=tag:Lab,Values=Week10" \
        --query 'Vpcs[0].VpcId' --output text 2>/dev/null)
    
    if [ "$vpc_id" = "None" ] || [ -z "$vpc_id" ]; then
        show_info "삭제할 VPC가 없습니다: $vpc_name"
        return 0
    fi
    
    show_info "VPC 발견: $vpc_name ($vpc_id)"
    
    # 1. NAT Gateway 삭제 (ENI 해제를 위해 먼저)
    cleanup_nat_gateways "$vpc_id"
    
    # 2. Route Tables 삭제
    cleanup_route_tables "$vpc_id"
    
    # 3. Internet Gateway 삭제
    cleanup_internet_gateways "$vpc_id"
    
    # 4. Subnets 삭제
    cleanup_subnets "$vpc_id"
    
    # 5. 남은 ENI 강제 정리 (ECS 등에서 남긴 ENI)
    cleanup_enis "$vpc_id"
    
    # 6. Security Groups 삭제 (NAT Gateway/Subnet 삭제 후 ENI 해제되어야 삭제 가능)
    cleanup_security_groups "$vpc_id"
    
    # 7. VPC 삭제
    cleanup_vpc "$vpc_id" "$vpc_name"
}

# Security Groups 삭제
cleanup_security_groups() {
    local vpc_id=$1
    show_info "Security Groups 삭제 중..."
    
    # Lab 태그가 있는 SG 조회
    local sg_ids=$(aws ec2 describe-security-groups \
        --filters "Name=vpc-id,Values=$vpc_id" "Name=tag:Lab,Values=Week10" \
        --query 'SecurityGroups[?GroupName!=`default`].GroupId' --output text 2>/dev/null)
    
    if [ -z "$sg_ids" ] || [ "$sg_ids" = "None" ]; then
        # 태그 없이 이름으로 재시도
        sg_ids=$(aws ec2 describe-security-groups \
            --filters "Name=vpc-id,Values=$vpc_id" "Name=group-name,Values=CloudArchitect-Lab-*" \
            --query 'SecurityGroups[?GroupName!=`default`].GroupId' --output text 2>/dev/null)
    fi
    
    if [ -n "$sg_ids" ] && [ "$sg_ids" != "None" ]; then
        # 1단계: 모든 SG의 인바운드/아웃바운드 규칙 먼저 제거 (SG 간 참조 해제)
        for sg_id in $sg_ids; do
            # 인바운드 규칙 조회 및 제거
            local ingress_rules=$(aws ec2 describe-security-groups --group-ids "$sg_id" \
                --query 'SecurityGroups[0].IpPermissions' --output json 2>/dev/null)
            if [ -n "$ingress_rules" ] && [ "$ingress_rules" != "[]" ] && [ "$ingress_rules" != "null" ]; then
                aws ec2 revoke-security-group-ingress --group-id "$sg_id" --ip-permissions "$ingress_rules" >/dev/null 2>&1
            fi
            
            # 아웃바운드 규칙 조회 및 제거
            local egress_rules=$(aws ec2 describe-security-groups --group-ids "$sg_id" \
                --query 'SecurityGroups[0].IpPermissionsEgress' --output json 2>/dev/null)
            if [ -n "$egress_rules" ] && [ "$egress_rules" != "[]" ] && [ "$egress_rules" != "null" ]; then
                aws ec2 revoke-security-group-egress --group-id "$sg_id" --ip-permissions "$egress_rules" >/dev/null 2>&1
            fi
        done
        show_info "Security Group 규칙 제거 완료"
        
        # 2단계: SG 삭제
        for sg_id in $sg_ids; do
            if aws ec2 delete-security-group --group-id "$sg_id" >/dev/null 2>&1; then
                show_success "Security Group 삭제: $sg_id"
            else
                show_error "Security Group 삭제 실패: $sg_id"
            fi
        done
    else
        show_info "삭제할 Security Group이 없습니다"
    fi
}

# NAT Gateways 삭제
cleanup_nat_gateways() {
    local vpc_id=$1
    show_info "NAT Gateways 삭제 중..."
    
    local nat_gw_ids=$(aws ec2 describe-nat-gateways \
        --filter "Name=vpc-id,Values=$vpc_id" "Name=tag:Lab,Values=Week10" \
        --query 'NatGateways[?State==`available`].NatGatewayId' --output text 2>/dev/null)
    
    if [ -n "$nat_gw_ids" ] && [ "$nat_gw_ids" != "None" ]; then
        for nat_id in $nat_gw_ids; do
            # EIP 정보 가져오기
            local eip_id=$(aws ec2 describe-nat-gateways --nat-gateway-ids "$nat_id" \
                --query 'NatGateways[0].NatGatewayAddresses[0].AllocationId' --output text 2>/dev/null)
            
            # NAT Gateway 삭제
            aws ec2 delete-nat-gateway --nat-gateway-id "$nat_id" >/dev/null 2>&1
            show_success "NAT Gateway 삭제: $nat_id"
            
            # NAT Gateway 삭제 대기
            show_info "NAT Gateway 삭제 대기 중..."
            aws ec2 wait nat-gateway-deleted --nat-gateway-ids "$nat_id" 2>/dev/null || sleep 30
            
            # EIP 해제
            if [ -n "$eip_id" ] && [ "$eip_id" != "None" ]; then
                aws ec2 release-address --allocation-id "$eip_id" >/dev/null 2>&1
                show_success "Elastic IP 해제: $eip_id"
            fi
        done
    fi
}

# Route Tables 삭제
cleanup_route_tables() {
    local vpc_id=$1
    show_info "Route Tables 삭제 중..."
    
    local rt_ids=$(aws ec2 describe-route-tables \
        --filters "Name=vpc-id,Values=$vpc_id" "Name=tag:Lab,Values=Week10" \
        --query 'RouteTables[].RouteTableId' --output text 2>/dev/null)
    
    if [ -n "$rt_ids" ] && [ "$rt_ids" != "None" ]; then
        for rt_id in $rt_ids; do
            # Route Table Association 해제
            local assoc_ids=$(aws ec2 describe-route-tables --route-table-ids "$rt_id" \
                --query 'RouteTables[0].Associations[?!Main].RouteTableAssociationId' --output text 2>/dev/null)
            if [ -n "$assoc_ids" ] && [ "$assoc_ids" != "None" ]; then
                for assoc_id in $assoc_ids; do
                    aws ec2 disassociate-route-table --association-id "$assoc_id" >/dev/null 2>&1
                done
            fi
            
            if aws ec2 delete-route-table --route-table-id "$rt_id" >/dev/null 2>&1; then
                show_success "Route Table 삭제: $rt_id"
            else
                show_error "Route Table 삭제 실패: $rt_id"
            fi
        done
    fi
}

# Internet Gateways 삭제
cleanup_internet_gateways() {
    local vpc_id=$1
    show_info "Internet Gateways 삭제 중..."
    
    local igw_ids=$(aws ec2 describe-internet-gateways \
        --filters "Name=attachment.vpc-id,Values=$vpc_id" "Name=tag:Lab,Values=Week10" \
        --query 'InternetGateways[].InternetGatewayId' --output text 2>/dev/null)
    
    if [ -n "$igw_ids" ] && [ "$igw_ids" != "None" ]; then
        for igw_id in $igw_ids; do
            # VPC에서 분리
            aws ec2 detach-internet-gateway --internet-gateway-id "$igw_id" --vpc-id "$vpc_id" >/dev/null 2>&1
            # IGW 삭제
            aws ec2 delete-internet-gateway --internet-gateway-id "$igw_id" >/dev/null 2>&1
            show_success "Internet Gateway 삭제: $igw_id"
        done
    fi
}

# Subnets 삭제
cleanup_subnets() {
    local vpc_id=$1
    show_info "Subnets 삭제 중..."
    
    local subnet_ids=$(aws ec2 describe-subnets \
        --filters "Name=vpc-id,Values=$vpc_id" "Name=tag:Lab,Values=Week10" \
        --query 'Subnets[].SubnetId' --output text 2>/dev/null)
    
    if [ -n "$subnet_ids" ] && [ "$subnet_ids" != "None" ]; then
        for subnet_id in $subnet_ids; do
            aws ec2 delete-subnet --subnet-id "$subnet_id" >/dev/null 2>&1
            show_success "Subnet 삭제: $subnet_id"
        done
    fi
}

# VPC 내 남은 ENI 강제 정리
cleanup_enis() {
    local vpc_id=$1
    show_info "VPC 내 남은 ENI 정리 중..."
    
    local eni_ids=$(aws ec2 describe-network-interfaces \
        --filters "Name=vpc-id,Values=$vpc_id" \
        --query 'NetworkInterfaces[].NetworkInterfaceId' --output text 2>/dev/null)
    
    if [ -n "$eni_ids" ] && [ "$eni_ids" != "None" ]; then
        for eni_id in $eni_ids; do
            # ENI attachment 해제
            local attachment_id=$(aws ec2 describe-network-interfaces --network-interface-ids "$eni_id" \
                --query 'NetworkInterfaces[0].Attachment.AttachmentId' --output text 2>/dev/null)
            if [ -n "$attachment_id" ] && [ "$attachment_id" != "None" ]; then
                aws ec2 detach-network-interface --attachment-id "$attachment_id" --force >/dev/null 2>&1
                sleep 5
            fi
            # ENI 삭제
            if aws ec2 delete-network-interface --network-interface-id "$eni_id" >/dev/null 2>&1; then
                show_success "ENI 삭제: $eni_id"
            fi
        done
    else
        show_info "정리할 ENI가 없습니다"
    fi
}

# VPC 삭제
cleanup_vpc() {
    local vpc_id=$1
    local vpc_name=$2
    show_info "VPC 삭제 중: $vpc_name"
    
    local vpc_retry=0
    while [ $vpc_retry -lt 3 ]; do
        if aws ec2 delete-vpc --vpc-id "$vpc_id" >/dev/null 2>&1; then
            show_success "VPC 삭제 완료: $vpc_name ($vpc_id)"
            return 0
        else
            vpc_retry=$((vpc_retry + 1))
            if [ $vpc_retry -lt 3 ]; then
                show_warning "VPC 삭제 재시도 중... ($vpc_retry/3)"
                sleep 15
            else
                show_error "VPC 삭제 실패: $vpc_name ($vpc_id)"
            fi
        fi
    done
}

# ECR 리포지토리 정리 함수
cleanup_ecr_repository() {
    show_info "ECR 리포지토리 정리 중..."
    
    local repo_name="cloudarchitect-lab-webapp"
    
    # 기존 리포지토리 확인
    local existing_repo=$(aws ecr describe-repositories --repository-names "$repo_name" --query 'repositories[0].repositoryName' --output text 2>/dev/null)
    
    if [ "$existing_repo" != "$repo_name" ] || [ -z "$existing_repo" ]; then
        show_info "삭제할 ECR 리포지토리가 없습니다: $repo_name"
        return 0
    fi
    
    show_info "ECR 리포지토리 발견: $repo_name"
    
    # 리포지토리 내 이미지 확인
    local image_count=$(aws ecr list-images --repository-name "$repo_name" --query 'length(imageIds)' --output text 2>/dev/null || echo "0")
    
    if [ "$image_count" -gt 0 ]; then
        show_info "리포지토리 내 이미지 삭제 중... ($image_count개)"
        
        # 모든 이미지 삭제
        local image_digests=$(aws ecr list-images --repository-name "$repo_name" --query 'imageIds[*].imageDigest' --output text 2>/dev/null)
        
        if [ -n "$image_digests" ] && [ "$image_digests" != "None" ]; then
            for digest in $image_digests; do
                aws ecr batch-delete-image --repository-name "$repo_name" --image-ids imageDigest="$digest" >/dev/null 2>&1
            done
            show_success "리포지토리 내 이미지 삭제 완료"
        fi
    else
        show_info "리포지토리가 비어있습니다"
    fi
    
    # 리포지토리 삭제
    show_info "ECR 리포지토리 삭제 중: $repo_name"
    
    if aws ecr delete-repository --repository-name "$repo_name" --force >/dev/null 2>&1; then
        show_success "ECR 리포지토리 삭제 완료: $repo_name"
    else
        show_error "ECR 리포지토리 삭제 실패: $repo_name"
        show_info "가능한 원인:"
        echo "  • ECR 권한 부족"
        echo "  • 리포지토리가 다른 서비스에서 사용 중"
        echo "  • 네트워크 연결 문제"
        return 1
    fi
}

# ECS 리소스 정리 함수
cleanup_ecs_resources() {
    show_info "ECS 리소스 정리 중..."
    
    local cluster_name="CloudArchitect-Lab-Cluster"
    
    # ECS 클러스터 확인
    local cluster_arn=$(aws ecs describe-clusters --clusters "$cluster_name" --query 'clusters[0].clusterArn' --output text 2>/dev/null)
    
    if [ "$cluster_arn" = "None" ] || [ -z "$cluster_arn" ] || [[ "$cluster_arn" == *"MISSING"* ]]; then
        show_info "삭제할 ECS 클러스터가 없습니다: $cluster_name"
        return 0
    fi
    
    show_info "ECS 클러스터 발견: $cluster_name"
    
    # 클러스터 내 모든 서비스 조회 및 삭제
    local service_arns=$(aws ecs list-services --cluster "$cluster_name" --query 'serviceArns[]' --output text 2>/dev/null)
    
    if [ -n "$service_arns" ] && [ "$service_arns" != "None" ]; then
        for service_arn in $service_arns; do
            local svc_name=$(echo "$service_arn" | awk -F'/' '{print $NF}')
            show_info "ECS 서비스 삭제 중: $svc_name"
            
            # 서비스 desired count를 0으로 설정
            aws ecs update-service --cluster "$cluster_name" --service "$service_arn" --desired-count 0 >/dev/null 2>&1
            
            # 서비스 삭제
            aws ecs delete-service --cluster "$cluster_name" --service "$service_arn" --force >/dev/null 2>&1
            
            show_success "ECS 서비스 삭제 요청 완료: $svc_name"
        done
        
        # 모든 서비스가 INACTIVE 될 때까지 대기 (최대 3분)
        show_info "ECS 서비스 삭제 대기 중... (최대 3분)"
        local wait_count=0
        while [ $wait_count -lt 36 ]; do
            local active_services=$(aws ecs list-services --cluster "$cluster_name" --query 'length(serviceArns)' --output text 2>/dev/null)
            if [ "$active_services" = "0" ] || [ -z "$active_services" ] || [ "$active_services" = "None" ]; then
                break
            fi
            sleep 5
            wait_count=$((wait_count + 1))
        done
        
        show_success "모든 ECS 서비스 삭제 완료"
    else
        show_info "삭제할 ECS 서비스가 없습니다"
    fi
    
    # 실행 중인 태스크 확인 및 중지
    local task_arns=$(aws ecs list-tasks --cluster "$cluster_name" --query 'taskArns[]' --output text 2>/dev/null)
    
    if [ -n "$task_arns" ] && [ "$task_arns" != "None" ]; then
        show_info "실행 중인 태스크 중지 중..."
        for task_arn in $task_arns; do
            aws ecs stop-task --cluster "$cluster_name" --task "$task_arn" >/dev/null 2>&1
        done
        show_success "모든 태스크 중지 요청 완료"
        
        # 태스크 완전 종료 대기 (최대 3분)
        show_info "태스크 종료 대기 중... (최대 3분)"
        local task_wait=0
        while [ $task_wait -lt 36 ]; do
            local running_tasks=$(aws ecs list-tasks --cluster "$cluster_name" --desired-status RUNNING --query 'length(taskArns)' --output text 2>/dev/null)
            if [ "$running_tasks" = "0" ] || [ -z "$running_tasks" ] || [ "$running_tasks" = "None" ]; then
                break
            fi
            sleep 5
            task_wait=$((task_wait + 1))
        done
        show_success "모든 태스크 종료 완료"
    fi
    
    # ECS 클러스터 삭제 (최대 6회, 20초 간격)
    show_info "ECS 클러스터 삭제 중: $cluster_name"
    local cluster_retry=0
    while [ $cluster_retry -lt 6 ]; do
        if aws ecs delete-cluster --cluster "$cluster_name" >/dev/null 2>&1; then
            show_success "ECS 클러스터 삭제 완료: $cluster_name"
            break
        else
            cluster_retry=$((cluster_retry + 1))
            if [ $cluster_retry -lt 6 ]; then
                show_warning "ECS 클러스터 삭제 재시도 중... ($cluster_retry/6)"
                sleep 20
            else
                show_error "ECS 클러스터 삭제 실패: $cluster_name (수동 삭제가 필요할 수 있습니다)"
            fi
        fi
    done
    
    # Task Definition 비활성화
    show_info "Task Definition 비활성화 중..."
    local task_def_family="cloudarchitect-lab-task"
    local task_def_arns=$(aws ecs list-task-definitions --family-prefix "$task_def_family" --status ACTIVE --query 'taskDefinitionArns[]' --output text 2>/dev/null)
    
    if [ -n "$task_def_arns" ] && [ "$task_def_arns" != "None" ]; then
        for task_def_arn in $task_def_arns; do
            aws ecs deregister-task-definition --task-definition "$task_def_arn" >/dev/null 2>&1
        done
        show_success "Task Definition 비활성화 완료"
    else
        show_info "비활성화할 Task Definition이 없습니다"
    fi
}

# ALB 및 Target Group 정리 함수
cleanup_alb_resources() {
    show_info "ALB 및 Target Group 정리 중..."
    
    local alb_name="CloudArchitect-Lab-ALB"
    local tg_name="CloudArchitect-Lab-TG"
    
    # ALB 확인 및 삭제
    local alb_arn=$(aws elbv2 describe-load-balancers --names "$alb_name" --query 'LoadBalancers[0].LoadBalancerArn' --output text 2>/dev/null)
    
    if [ "$alb_arn" != "None" ] && [ -n "$alb_arn" ]; then
        show_info "ALB 삭제 중: $alb_name"
        aws elbv2 delete-load-balancer --load-balancer-arn "$alb_arn" >/dev/null 2>&1
        
        # ALB 삭제 대기
        show_info "ALB 삭제 대기 중... (약 1분)"
        sleep 60
        
        show_success "ALB 삭제 완료: $alb_name"
    else
        show_info "삭제할 ALB가 없습니다: $alb_name"
    fi
    
    # Target Group 확인 및 삭제
    local tg_arn=$(aws elbv2 describe-target-groups --names "$tg_name" --query 'TargetGroups[0].TargetGroupArn' --output text 2>/dev/null)
    
    if [ "$tg_arn" != "None" ] && [ -n "$tg_arn" ]; then
        show_info "Target Group 삭제 중: $tg_name"
        aws elbv2 delete-target-group --target-group-arn "$tg_arn" >/dev/null 2>&1
        show_success "Target Group 삭제 완료: $tg_name"
    else
        show_info "삭제할 Target Group이 없습니다: $tg_name"
    fi
}

# 로컬 파일 정리 함수
cleanup_local_files() {
    show_info "로컬 파일 정리 중..."
    
    # 환경 파일 삭제
    if [ -f "week10-prerequisites.env" ]; then
        rm -f week10-prerequisites.env
        show_success "환경 파일 삭제 완료: week10-prerequisites.env"
    fi
    
    # 로그 파일 삭제
    local log_files=$(ls week10-*.log 2>/dev/null || true)
    if [ -n "$log_files" ]; then
        rm -f week10-*.log
        show_success "로그 파일 삭제 완료"
    fi
    
    show_success "로컬 파일 정리 완료"
}

# 정리 검증 함수
verify_cleanup() {
    show_info "정리 결과 검증 중..."
    
    # ECR 리포지토리 삭제 확인
    local repo_check=$(aws ecr describe-repositories --repository-names "cloudarchitect-lab-webapp" --query 'repositories[0].repositoryName' --output text 2>/dev/null)
    
    if [ "$repo_check" = "cloudarchitect-lab-webapp" ]; then
        show_warning "ECR 리포지토리가 아직 존재합니다: cloudarchitect-lab-webapp"
        return 1
    else
        show_success "ECR 리포지토리 삭제 검증 완료"
    fi
    
    return 0
}

# 완료 요약 표시 함수
show_cleanup_summary() {
    echo ""
    show_success "🎉 Week10 ECS 컨테이너 인프라 정리가 완료되었습니다!"
    echo ""
    
    echo "📋 정리된 주요 리소스:"
    echo "  ✅ ECS 클러스터: CloudArchitect-Lab-Cluster"
    echo "  ✅ ECS 서비스: cloudarchitect-lab-service"
    echo "  ✅ ECS Task Definition: cloudarchitect-lab-task (비활성화)"
    echo "  ✅ Application Load Balancer: CloudArchitect-Lab-ALB"
    echo "  ✅ Target Group: CloudArchitect-Lab-TG"
    echo "  ✅ ECR 리포지토리: cloudarchitect-lab-webapp"
    echo "  ✅ 리포지토리 내 모든 Docker 이미지"
    echo "  ✅ VPC: CloudArchitect-Lab-VPC (10.0.0.0/16)"
    echo "  ✅ Internet Gateway, NAT Gateway, Elastic IP"
    echo "  ✅ Public/Private Subnets (4개, Multi-AZ)"
    echo "  ✅ Route Tables (Public/Private)"
    echo "  ✅ Security Groups (ALB-SG, ECS-SG)"
    echo "  ✅ 로컬 환경 파일 및 로그 파일"
    echo ""
    
    echo "💡 참고사항:"
    echo "  • 모든 Week10 리소스가 자동으로 정리되었습니다"
    echo "  • IAM 역할 ecsTaskExecutionRole은 AWS 관리형 역할이므로 유지됩니다"
    echo "  • 다른 실습에서 생성된 리소스는 각각의 cleanup 스크립트로 정리하세요"
    echo ""
    
    show_success "Week10 정리 스크립트 실행 완료"
}

# 메인 실행 함수
main() {
    # 헤더 표시
    echo "================================"
    echo "Week10: Amazon ECS 서비스 배포 - 컨테이너 오케스트레이션 관리 정리"
    echo "================================"
    echo "목적: Week10에서 생성된 모든 리소스를 안전하게 정리"
    echo "================================"
    echo ""
    
    # AWS 환경 확인
    show_info "AWS 환경 확인 중..."
    local region=$(aws configure get region 2>/dev/null || echo "")
    if [ -z "$region" ]; then
        region="${AWS_REGION:-${AWS_DEFAULT_REGION:-ap-northeast-2}}"
    fi
    local account_id=$(aws sts get-caller-identity --query Account --output text 2>/dev/null || echo "미설정")
    local user_arn=$(aws sts get-caller-identity --query Arn --output text 2>/dev/null || echo "미설정")
    
    echo "현재 리전: $region"
    echo "계정 ID: $account_id"
    echo "사용자: $user_arn"
    echo ""
    
    # Week10 리소스 확인
    show_info "Week10 관련 리소스 확인 중..."
    
    # ECS 클러스터 확인
    local cluster_arn=$(aws ecs describe-clusters --clusters "CloudArchitect-Lab-Cluster" --query 'clusters[0].clusterArn' --output text 2>/dev/null)
    
    # ALB 확인
    local alb_arn=$(aws elbv2 describe-load-balancers --names "CloudArchitect-Lab-ALB" --query 'LoadBalancers[0].LoadBalancerArn' --output text 2>/dev/null)
    
    # ECR 리포지토리 확인
    local ecr_repo=$(aws ecr describe-repositories --repository-names "cloudarchitect-lab-webapp" --query 'repositories[0].repositoryName' --output text 2>/dev/null)
    
    # VPC 확인
    local vpc_id=$(aws ec2 describe-vpcs \
        --filters "Name=tag:Name,Values=CloudArchitect-Lab-VPC" "Name=tag:Lab,Values=Week10" \
        --query 'Vpcs[0].VpcId' --output text 2>/dev/null)
    
    echo ""
    show_important "🗑️ 삭제 계획:"
    echo ""
    echo "  📋 정리할 리소스:"
    
    # ECS 리소스
    if [ "$cluster_arn" != "None" ] && [ -n "$cluster_arn" ] && [[ "$cluster_arn" != *"MISSING"* ]]; then
        echo "    🏗️ ECS 클러스터: CloudArchitect-Lab-Cluster"
        echo "    🚀 ECS 서비스: cloudarchitect-lab-service"
        echo "    📋 Task Definition: cloudarchitect-lab-task"
    else
        echo "    ℹ️ 삭제할 ECS 리소스가 없습니다"
    fi
    
    # ALB 리소스
    if [ "$alb_arn" != "None" ] && [ -n "$alb_arn" ]; then
        echo "    ⚖️ Application Load Balancer: CloudArchitect-Lab-ALB"
        echo "    🎯 Target Group: CloudArchitect-Lab-TG"
    else
        echo "    ℹ️ 삭제할 ALB가 없습니다"
    fi
    
    # VPC 리소스
    if [ "$vpc_id" != "None" ] && [ -n "$vpc_id" ]; then
        echo "    🌐 VPC: CloudArchitect-Lab-VPC ($vpc_id)"
        echo "    🌍 Internet Gateway, NAT Gateway, Elastic IP"
        echo "    🏢 Public/Private Subnets (4개)"
        echo "    🗺️ Route Tables (Public/Private)"
        echo "    🛡️ Security Groups (ALB-SG, ECS-SG)"
    else
        echo "    ℹ️ 삭제할 VPC가 없습니다"
    fi
    
    # ECR 리소스
    if [ "$ecr_repo" = "cloudarchitect-lab-webapp" ]; then
        local repo_uri=$(aws ecr describe-repositories --repository-names "cloudarchitect-lab-webapp" --query 'repositories[0].repositoryUri' --output text)
        local image_count=$(aws ecr list-images --repository-name "cloudarchitect-lab-webapp" --query 'length(imageIds)' --output text 2>/dev/null || echo "0")
        echo "    🏪 ECR 리포지토리: cloudarchitect-lab-webapp ($repo_uri)"
        echo "    🐳 컨테이너 이미지: $image_count개"
    else
        echo "    ℹ️ 삭제할 ECR 리포지토리가 없습니다"
    fi
    
    echo "    📁 로컬 파일: 환경 파일, 로그 파일"
    echo ""
    
    echo "  💡 참고사항:"
    echo "    • 모든 Week10 리소스를 자동으로 정리합니다"
    echo "    • 예상 소요 시간: 약 3-5분"
    echo ""
    
    # 사용자 확인
    read -p "위 계획대로 Week10 리소스를 정리하시겠습니까? (y/N): " confirm
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        show_info "Week10 정리가 취소되었습니다."
        exit 0
    fi
    
    show_info "Week10 리소스 정리를 시작합니다..."
    echo ""
    
    # 리소스 정리 (단계별)
    show_progress 1 5 "ECS 리소스 정리 중..."
    cleanup_ecs_resources
    echo ""
    
    show_progress 2 5 "ALB 및 Target Group 정리 중..."
    cleanup_alb_resources
    echo ""
    
    show_progress 3 5 "ECR 리포지토리 정리 중..."
    cleanup_ecr_repository
    echo ""
    
    show_progress 4 5 "VPC 네트워크 인프라 정리 중..."
    cleanup_vpc_infrastructure
    echo ""
    
    show_progress 5 5 "로컬 파일 정리 중..."
    cleanup_local_files
    echo ""
    
    # 정리 검증
    if verify_cleanup; then
        show_success "정리 검증 완료"
    else
        show_warning "일부 리소스 정리 실패"
    fi
    
    # 완료 요약
    show_cleanup_summary
}

# 스크립트 실행
main "$@"